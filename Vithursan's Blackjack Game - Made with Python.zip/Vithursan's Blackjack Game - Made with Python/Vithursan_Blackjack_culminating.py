# Classic Blackjack
# By Vithursan Sarvalogan


import random
from easygui import choicebox
from easygui import msgbox
from easygui import integerbox
from easygui import textbox

# Dictionary used to generate deck of cards
CardDictionary = {1:'Ace', 2:'Two', 3:'Three', 4:'Four', 5:'Five', 6:'Six', 7:'Seven', 8:'Eight', 9:'Nine', 10:'Ten', 11:'Jack', 12:'Queen', 13:'King',
                  14:'Diamonds', 15:'Spades', 16:'Hearts', 17:'Clubs'}
    
# Function that generates the initial hand, which consists of 2 random cards
def hand(CardDictionary, x):
    hand = [] # Stores the 2 draw cards (combination of RandomCard and RandomSuit variables) and is used when displaying the sentence of the player and dealer's initial hands
    card_value_list = [] # Stores the value of each drawn card; list used for identifying the values on the cards in the dealer's initial hand when revealing hole card and in making insurance bets
    RandomCard_list = []
    RandomSuit_list = []
    hand_value = 0 # Tracks the value of the player and dealer's hand, used to checker whether the hand is below, at, or over a value of 21

    for i in range(x):
        RandomCard = random.randint(1, 13) # Generates value of card, from ace (1) to king (3)
        RandomSuit = random.randint(14, 17) # Generates suit of card, from diamonds (14) to clubs (17)

        RandomCard_list.append(RandomCard)
        RandomSuit_list.append(RandomSuit)

        
        hand.append(CardDictionary[RandomCard] + str(' of ') + CardDictionary[RandomSuit]) # Combines generated card value and suit to make a proper card (ex. Ten of Diamonds)

        if RandomCard == 11 or RandomCard == 12 or RandomCard == 13:
            hand_value += 10 # All face card (jack, queen, king) have a value of 10
            card_value_list.append(10)

        elif 2 <= RandomCard <= 10:
            hand_value += RandomCard # Cards ranging from 2 to ten have a value of their corresponding number
            card_value_list.append(RandomCard)

        elif RandomCard == 1:
            if hand_value >= 11:
                hand_value += 1 # Ace has a value of 11 when the hand is over a value of 11, otherwise the hand would be bust (over 21)
                card_value_list.append(1)
            else:
                hand_value += 11 # Ace has a value of 11 when hand is below a value of 11
                card_value_list.append(11)
            # The value of drawn Aces can change depending on the hand value throughout the game, as it simulates blackjack in real life where the player and dealer can determine the value of their ace

    Card1 = hand[0]
    Card2 = hand[1]
    RandomCard1 = RandomCard_list[0]
    RandomCard2 = RandomCard_list[1]
    RandomSuit1 = RandomSuit_list[0]
    RandomSuit2 = RandomSuit_list[1]
    
    return Card1, Card2, hand_value, card_value_list, RandomCard1, RandomCard2, RandomSuit1, RandomSuit2
# Function end

# This function takes the card value and suit of a geneerated card and displays the corresponding card image
def image_convertor(RandomCard, RandomSuit):
    if RandomCard == 1 and RandomSuit == 14:
        image = 'ace_diamonds.gif'
    elif RandomCard == 1 and RandomSuit == 15:
        image = 'ace_spades.gif'
    elif RandomCard == 1 and RandomSuit == 16:
        image = 'ace_hearts.gif'
    elif RandomCard == 1 and RandomSuit == 17:
        image = 'ace_clubs.gif'
    elif RandomCard == 2 and RandomSuit == 14:
        image = '2_diamonds.gif'
    elif RandomCard == 2 and RandomSuit == 15:
        image = '2_spades.gif'
    elif RandomCard == 2 and RandomSuit == 16:
        image = '2_hearts.gif'
    elif RandomCard == 2 and RandomSuit == 17:
        image = '2_clubs.gif'
    elif RandomCard == 3 and RandomSuit == 14:
        image = '3_diamonds.gif'
    elif RandomCard == 3 and RandomSuit == 15:
        image = '3_spades.gif'
    elif RandomCard == 3 and RandomSuit == 16:
        image = '3_hearts.gif'
    elif RandomCard == 3 and RandomSuit == 17:
        image = '3_clubs.gif'
    elif RandomCard == 4 and RandomSuit == 14:
        image = '4_diamonds.gif'
    elif RandomCard == 4 and RandomSuit == 15:
        image = '4_spades.gif'
    elif RandomCard == 4 and RandomSuit == 16:
        image = '4_hearts.gif'
    elif RandomCard == 4 and RandomSuit == 17:
        image = '4_clubs.gif'
    elif RandomCard == 5 and RandomSuit == 14:
        image = '5_diamonds.gif'
    elif RandomCard == 5 and RandomSuit == 15:
        image = '5_spades.gif'
    elif RandomCard == 5 and RandomSuit == 16:
        image = '5_hearts.gif'
    elif RandomCard == 5 and RandomSuit == 17:
        image = '5_clubs.gif'
    elif RandomCard == 6 and RandomSuit == 14:
        image = '6_diamonds.gif'
    elif RandomCard == 6 and RandomSuit == 15:
        image = '6_spades.gif'
    elif RandomCard == 6 and RandomSuit == 16:
        image = '6_hearts.gif'
    elif RandomCard == 6 and RandomSuit == 17:
        image = '6_clubs.gif'
    elif RandomCard == 7 and RandomSuit == 14:
        image = '7_diamonds.gif'
    elif RandomCard == 7 and RandomSuit == 15:
        image = '7_spades.gif'
    elif RandomCard == 7 and RandomSuit == 16:
        image = '7_hearts.gif'
    elif RandomCard == 7 and RandomSuit == 17:
        image = '7_clubs.gif'
    elif RandomCard == 8 and RandomSuit == 14:
        image = '8_diamonds.gif'
    elif RandomCard == 8 and RandomSuit == 15:
        image = '8_spades.gif'
    elif RandomCard == 8 and RandomSuit == 16:
        image = '8_hearts.gif'
    elif RandomCard == 8 and RandomSuit == 17:
        image = '8_clubs.gif'
    elif RandomCard == 9 and RandomSuit == 14:
        image = '9_diamonds.gif'
    elif RandomCard == 9 and RandomSuit == 15:
        image = '9_spades.gif'
    elif RandomCard == 9 and RandomSuit == 16:
        image = '9_hearts.gif'
    elif RandomCard == 9 and RandomSuit == 17:
        image = '9_clubs.gif'
    elif RandomCard == 10 and RandomSuit == 14:
        image = '10_diamonds.gif'
    elif RandomCard == 10 and RandomSuit == 15:
        image = '10_spades.gif'
    elif RandomCard == 10 and RandomSuit == 16:
        image = '10_hearts.gif'
    elif RandomCard == 10 and RandomSuit == 17:
        image = '10_clubs.gif'
    elif RandomCard == 11 and RandomSuit == 14:
        image = 'jack_diamonds.gif'
    elif RandomCard == 11 and RandomSuit == 15:
        image = 'jack_spades.gif'
    elif RandomCard == 11 and RandomSuit == 16:
        image = 'jack_hearts.gif'
    elif RandomCard == 11 and RandomSuit == 17:
        image = 'jack_clubs.gif'
    elif RandomCard == 12 and RandomSuit == 14:
        image = 'queen_diamonds.gif'
    elif RandomCard == 12 and RandomSuit == 15:
        image = 'queen_spades.gif'
    elif RandomCard == 12 and RandomSuit == 16:
        image = 'queen_hearts.gif'
    elif RandomCard == 12 and RandomSuit == 17:
        image = 'queen_clubs.gif'
    elif RandomCard == 13 and RandomSuit == 14:
        image = 'king_diamonds.gif'
    elif RandomCard == 13 and RandomSuit == 15:
        image = 'king_spades.gif'
    elif RandomCard == 13 and RandomSuit == 16:
        image = 'king_hearts.gif'
    elif RandomCard == 13 and RandomSuit == 17:
        image = 'king_clubs.gif'

    return image
# Function end
        

# Function that executes hit option, which is similar to the "hand" function above, but only returns 1 card rather than 2 and returns different variable values
def hit(CardDictionary, hand_value):
    continued_hand = [] # Stores the dealt card
    continued_hand_value = 0 # Tracks value of the dealt card

    RandomCard = random.randint(1, 13) # Generates card value
    RandomSuit = random.randint(14, 17) # Generates card suit

    continued_hand.append(CardDictionary[RandomCard] + str(' of ') + CardDictionary[RandomSuit]) #

    if RandomCard == 11 or RandomCard == 12 or RandomCard == 13:
        continued_hand_value += 10 # All face card (jack, queen, king) have a value of ten
            
    elif 2 <= RandomCard <= 10:
        continued_hand_value += RandomCard # Cards ranging from 2 to ten have a value of their corresponding number
            
    elif RandomCard == 1:
        if hand_value >= 11:
            continued_hand_value += 1 # Ace has a value of 11 when the hand is over a value of 11, otherwise the hand would be bust (over 21)
        else:
            continued_hand_value += 11 # Ace has a value of 11 when hand is below a value of 11
        # The value of drawn Aces can change depending on the hand value throughout the game, as it simulates blackjack in real life where the player and dealer can determine the value of their ace
        
    NewCard = continued_hand[0]
    HitRandomCard1 = RandomCard
    HitRandomSuit1 = RandomSuit

    return NewCard, continued_hand_value, HitRandomCard1, HitRandomSuit1
# Function ends

# Function displays play again menu, used when win/loss conditions are reached at various points throughout the game
def play_again_menu():
    msg = "Would you like to play again?"
    title = "End Options"
    choices = ["Play again", "Quit"]
    choice = choicebox(msg, title, choices)

    return choice
# Function ends


# Function that executes entire blackjack game
def main_game_loop(Chips):
    msg = "Welcome to Vithursan Sarvalogan's Blackjack!"
    title = "Blackjack Options Menu"
    choices = ["Start", "Help", "Quit"]
    choice = choicebox(msg, title, choices) # Starting screen options, where the user can start the game, ask for instructions on how to play, or quit the game

    while choice != "Start":

        if choice == "Help":
            msgbox("This is a program made by Vithursan Sarvalogan.")
            msgbox("To run this program, it requires python 3.7.2 and the easyGUI python module downloaded, along with an additional file called 'Vithursan's Computer Science Culminating', which contains various images used throughout the program.")
            msgbox("This program must be run from within the same file for the pictures to be imported.")
            msgbox("Blackjack is a casino card game that involves betting. The goal of the game is to get a hand value of 21 or as close to 21 without going over.")
            msgbox("Various features of this game program include betting, hitting, standing, insurance betting, doubling down, and blackjack hand wins.")
            text3 = "Betting involves chips which the player receives at the beginning of the game, from which the player can wager some or all of the chips and will either gain the amount they wager if they win or lose that amount if they lose." 
            text4 = "Hitting involves the player requesting a card from the dealer after the intial hand is dealt. This is when the player tries to get to or as close as possible to 21. If the player goes over 21, it means their hand is bust. The turn is then passed on to the dealer."
            text5 = "Standing is a choice is presented with hitting and it means the player wishes to no longer receive cards and maintain their card value. This is done if the player is confident in their current hand value and do not want to risk hitting and their hand going bust."
            text6 = "Doubling down is an available option with hitting and standing if the player has twice the chips of their original bet or more. When the player chooses this option, their bet at the beginning of the round is doubled and the player will receive one last card, after which they must stand. This is an option a player should consider when they want to risk more to gain more."
            text7 = "Blackjack hand is when the player and/or dealer start of with an initial hand that has a value of 21. If the player starts of with 21, the dealer reveals his face-down card. If the dealer does not have 21, the player wins. The dealer may have blackjack when their revealed card is an ace. If it is an ace, the player can make an insurance bet, provided that the player has chips remaining after placing their initial bet."
            text8 = "Insurance bets will be explained later it the game if a situation where an insurance bet can be made occurs."
            text9 = "The game starts of with the player placing a bet that they will win."
            text10 = "The intial hands are dealt to the player and dealer, from which blackjack hand and insurance bet conditions are checked."
            text11 = "The player will then have the options to hit and stand, as well as the option to double down depending on their remaining chips after their intial bet."
            text12 = "Once both the player's and dealer's turns are over, win/loss conditions are checked and the player wins or losses their bets accordingly."
            text13 = "The player has the freedom to hit as they please as long as they don't bust, but the dealer must stand once they reach a hand value of 17 or over."
            HELP_text = textbox(text = (text3 + text4 + text5 + text6 + text7 + text8 + text9 + text10 + text11 + text12 + text13), title = "Help Menu", msg = "Explanation of game")
            # Displays help menu
            
            choice = choicebox("Welcome to Vithursan Sarvalogan's Blackjack!", title, choices)
            # Brings user back to starting screen, where they can start, view instructions again, or quit 

        elif choice == "Quit":
            msgbox("The player has quit. The game will now close.")
            quit() # Closes the game window
            
#               <<<<<<<<<< MAIN GAME LOOP STARTS HERE >>>>>>>>>>

    # Prompts player to place their bet
    msg = ("You have " + str(Chips) + " chips. How much will you bet for this round?")
    title + "Place your bets!"
    bet = integerbox(msg, title, lowerbound = 1, upperbound = str(Chips))
    msgbox("Your bet of " + str(bet) + " was deducted from your total cash and placed in designated bet area.")

    msgbox("The player will now be dealt their hand by the dealer.")

    # 2 random cards will continue to be generated until 2 unique cards are generated, as there isn't more than one card of a certain value and suit in a deck of cards
    Card1, Card2, hand_value, card_value_list, RandomCard1, RandomCard2, RandomSuit1, RandomSuit2 = hand(CardDictionary, 2)
    while RandomCard1 == RandomCard2 and RandomSuit1 == RandomSuit2: # Ensures that 2 unique cards are generated with no duplicates
        Card1, Card2, hand_value, card_value_list, RandomCard1, RandomCard2, RandomSuit1, RandomSuit2 = hand(CardDictionary, 2)
    player_hand = hand
    player_hand_value = hand_value

    # Displays statement of the player's starting hand along with pictures of the cards
    msg = "The player's hand consists of the "+ str(Card1) + " and the " + str(Card2) + "."
    player_image_1 = image_convertor(RandomCard1, RandomSuit1)
    player_image_2 = image_convertor(RandomCard2, RandomSuit2)
    display = msgbox(msg, image = (player_image_1, player_image_2))
    
    msgbox("The value of this hand is " + str(player_hand_value) +".") # Displays the value of the player's starting hand

    msgbox("The dealer will now deal their own hand.")

    # 2 random cards will continue to be generated until 2 unique cards are generated, as there isn't more than one card of a certain value and suit in a deck of cards
    Card1, Card2, hand_value, card_value_list, RandomCard1, RandomCard2, RandomSuit1, RandomSuit2 = hand(CardDictionary, 2)
    while RandomCard1 == RandomCard2 and RandomSuit1 == RandomSuit2: # Ensures that 2 unique cards are generated with no duplicates
        Card1, Card2, hand_value, card_value_list, RandomCard1, RandomCard2, RandomSuit1, RandomSuit2 = hand(CardDictionary, 2)
    dealer_card_value_list = card_value_list
    dealer_hand_value = hand_value
    FaceDown = Card2

    # Makes a statement and displays only one of the dealer's cards, as in blackjack, the dealer does not reveal their second card until an insurance bet is made or it is their turn to receive cards 
    msg = "The dealer's hand consists of the "+ str(Card1) + " and one card face down."
    dealer_image_1 = image_convertor(RandomCard1, RandomSuit1)
    dealer_image_2 = image_convertor(RandomCard2, RandomSuit2)
    facedown_image = 'facedown_image.gif'
    display = msgbox(msg, image = (dealer_image_1, facedown_image))
    msgbox("The value of the face-up card is " + str(dealer_card_value_list[0]) +".")

    # Checks for blackjack, which is when either the dealer or player start of with an initial hand that already has a value of 21
    if player_hand_value == 21:
        msg = ("The player has started with a hand value of 21. The dealer reveals his hole card to be the " + str(FaceDown) + ".")
        display = msgbox(msg, image = dealer_image_2)
        msgbox("The value of the dealer's hand is " + str(dealer_hand_value) + ".")
        if dealer_hand_value == 21:
            msgbox("Both you and the dealer start with blackjack hands. It is a draw!")
        else:
            msgbox("Player wins! Player's initial Blackjack hand wins regardless of whether the dealer can hit to reach a hand value of 21.")
            msgbox("The player has won " + str(bet) + " chips.")
            Chips += bet

        choice = play_again_menu()
        if choice == "Quit":
                msgbox("The player has quit. The game will now close.")
                quit()
        else:
                main_game_loop(Chips)

    # Checks for blackjack conditions in dealer's hand
    # In blackjack, when the dealer's face-up card is an ace, players can make an insurance bet, which has a 2-1 payout, of whether the dealer's face-down card has a value of ten
    # If the player makes an insurance bet, the dealer will reveal their face-down card and the player will win or lose their bet accordingly
    # The player can only win or lose the insurance bet and their original bet will be returned
    # If they player does not make an insurance bet, normal play will resume
    # If player makes an insurance bet and wins, a new round starts. If the player loses, the bet is lost but normal play will resume, as the player can still win the original wager

    elif Chips - bet >= 1: # an insurance bet can only be made if the player has a minimum of 1 chip left after making their initial bet
        if RandomCard1 == 1: # Insurance bets can be made only when the dealer has an ace face-up from their initial hand
            # Player receives an explanation of what an insurance bet is
            msgbox("The dealer has an ace face-up. You have the option to place an insurance bet.")
            msgbox("An insurance bet is a bet of half your original bet, betting on whether the dealer's face-down card has a value of ten.")
            msgbox("This bet has a 2-1 payout, meaning the player receives twice the insurance bet value if they win, but lose only the insurance bet value if they lose.")
            msgbox("If the player chooses to make an insurance bet, the dealer will reveal their face-down card.")
            msgbox("If the face-down card doesn't have a value of 10, the player loses the insurance bet and normal play will resume, as it means the dealer does not have blackjack and the player can still win their original bet.")
            msbbox("If the face-down card has a value of 10, the player loses their original bet, but wins double the insurance bet, meaning the player maintains their original amount of chips. Afterwards, a new round will start.")

            msg = "Would you like to make an insurance bet?"
            title = "Insurance Bet"
            insurance_choices = ["Yes", "No"]
            insurance_choice = choicebox(msg, title, insurance_choices) # Player given option of whether they wish to make an insurance bet

            if insurance_choice == "Yes":
                   if bet // 2 <= Chips - bet:
                       limit = bet // 2 # An insurance bet over half the value of the player's initial bet cannot be made
                   elif bet // 2 > Chips - bet:
                       limit = Chips -bet # The player can bet all their remaining chips if it is less than half their initial bet
                   msg = "How much would you like to bet as insurance? (Maximum " +str(limit) + ")"
                   title = "Blackjack"
                   insurance_bet = integerbox(msg, title, lowerbound = 1, upperbound = limit)
                   msg = "The dealer will now reveal their face-down card, the hole card. The hole card is the " + str(FaceDown) + "."
                   display = msgbox(msg, image = dealer_image_2)
                   if dealer_card_value_list[0] == 10: # When player wins
                        msgbox("The hole card has a value of 10. The dealer has blackjack. You have lost your original bet, but have won the insurance bet.")
                        Chips -= bet # Player loses initial bet
                        Chips += insurance_bet * 2 # player wins double the insurance bet
                        choice = play_again_menu() # The dealer had 21, so this round is over and player can choose to quit or play again
                        if choice == "Quit":
                            msgbox("The player has quit. The game will now close.")
                            quit()
                        else:
                            main_game_loop(Chips) # As player chooses to play again, they are brought back to the starting menu
                   elif dealer_card_value_list[0] != 10: # When player loses
                        msgbox("The hole card does not have a value of 10. The dealer does not have blackjack. You have lost your insurance bet. Normal play will now proceed.")
                        Chips -= insurance_bet # insurance bet is lost and game continues
                          
    # This is where the options to hit and stand begin for the player
    msg = "Would you like to hit or stand?"
    title = "Blackjack"
    if bet * 2 <= Chips:
        choices = ["Stand", "Hit", "Double Down"] # Doubling down is only an option if the player has enough chips left to double their intial bet
    else:
        choices = ["Stand", "Hit"]
    choice = choicebox(msg, title, choices)
    while choice != "Stand": # Assumes that player selected hit option and deals player cards until a different option, doubling down or standing, is chosen

        NewCard, continued_hand_value, HitRandomCard1, HitRandomSuit1 = hit(CardDictionary, hand_value) # New cards are deal using "hit" function
        player_hand_value += continued_hand_value # Takes value of the newly dealt card and adds to the total value of the player's hand

        msg = "You received a " + str(NewCard) + ", which has a value of " + str(continued_hand_value) + "." # statement of the card received
        hit_image = image_convertor(HitRandomCard1, HitRandomSuit1)
        display = msgbox(msg, image = hit_image) # displays image of the newly dealt card
        msg = msgbox("Your new hand value is " + str(player_hand_value) + ".") # Displays updated hand value

        if choice == "Double Down":
            msgbox("As the player has chosen to double down, the player will stand at their current hand value of " + str(player_hand_value) + ".")
            msgbox("The player's initial bet of " +str(bet) + " has also doubled to " + str(bet * 2) + ".") # Statement that player has chosen to double down
            bet = bet * 2 # initial bet gets doubled
            break # doubling down means the player must stand after the last card they are dealt

        elif player_hand_value == 21:
            msg = msgbox("The player has reached 21! The dealer will now deal their cards.")
            break # player stands after reaching 21 and cannot hit or double down, as there is no reason to do so

        elif player_hand_value > 21:
            msg = msgbox("Bust! The player's hand value has exceeded 21 and the player has lost their bet. The dealer will now deal their cards.")
            break
        choice = choicebox(msg, title, choices) # Player presented with option to continue hitting, stand, or double down after a new card is dealt
            

    # This is where the hit sequence turn begins for the dealer
    msg = "The dealer will now reveal their face-down card, the hole card. The hole card is the " + str(FaceDown) + "." # Statement revealing dealer's face-down card
    display = msgbox(msg, image = dealer_image_2) # Displays image of dealer's initial face-down card
    msgbox("The dealer's hand value is " + str(dealer_hand_value) + ".") # Statement of dealer's full hand value now that the face-down card is known
    while dealer_hand_value < 17:

        # In Casino rules, the dealer must continue to hit until their hand reaches a value of 17 or over
        NewCard, continued_hand_value, HitRandomCard1, HitRandomSuit1 = hit(CardDictionary, hand_value)
        dealer_hand_value += continued_hand_value # adds value of newly dealt card to dealer's total hand value

        msg = "The dealer received a " + str(NewCard) + ", which has a value of " + str(continued_hand_value) + "." # Statement of newly dealt card
        hit_image = image_convertor(HitRandomCard1, HitRandomSuit1)
        display = msgbox(msg, image = hit_image) # Displays image of newly dealt card
        msgbox("The dealer's new hand value is " + str(dealer_hand_value) + ".") # Displays updated hand value
        
    # Dealer's stand option conditions
    if dealer_hand_value == 21:
        msgbox("The dealer has reached 21!") 
    elif dealer_hand_value > 21:
        msg = msgbox("Bust! The dealer has exceeded a hand value of 21.")
    else:
        msg = msgbox("The total of the dealers hand is now 17 and/or over. The dealer must now stand.")

    # ---------- Win/Lose conditions ----------

    # When the player and dealer are below a hand value of 21
    if player_hand_value < 21 and dealer_hand_value < 21:
        if player_hand_value > dealer_hand_value:
            msg = msgbox("The player wins! Your hand has a higher value than the dealer's hand.")
            Chips += bet
            msg = msgbox("The player has won " + str(bet) + " chips.")
        elif player_hand_value == dealer_hand_value:
            msg = msgbox("Tie! The player's hand and the dealer's hand have the same value.")
            msg = msgbox("The player's bet of " + str(bet) + " chips has been returned.")
        else:
            msg = msgbox("Dealer wins! The dealer's hand has a higher value than your hand.")
            msg = msgbox("The player has lost " + str(bet) + " chips.")
            Chips -= bet

    # When player busts, meaning they exceed a hand value of 21
    elif player_hand_value > 21:
        msg = msgbox("Dealer wins! When player busts, the player loses regardless of whether the dealer busts or not.")
        msg = msgbox("The player has lost " + str(bet) + " chips.")
        Chips -= bet

    # When player is below 21 or at 21 and dealer busts
    elif player_hand_value < 21 and dealer_hand_value > 21:
        msg = msgbox("The player wins! You have not exceeded 21 and the dealer busted.")
        msg = msgbox("The player has won " + str(bet) + " chips.")
        Chips += bet

    # When player reaches 21
    elif player_hand_value == 21:
        if dealer_hand_value > 21:
            msgbox("The player wins! You have reached 21 and dealer busted.")
            msgbox("The player has won " + str(bet) + " chips.")
            Chips += bet
        elif dealer_hand_value == 21:
            msgbox("Tie! your and the dealer's hands have reached 21.")
        else:
            msgbox("The player wins! You have reached 21 and dealer is below 21.")
            Chips += bet

    elif dealer_hand_value == 21 and player_hand_value != 21:
        msgbox("Dealer wins! The dealer has reached 21 and the player has not.")
        msg = msgbox("The player has lost " + str(bet) + " chips.")
        Chips -= bet
    
    if Chips == 0:
        msgbox("The player has lost all their chips and can no longer play.")
        msgbox("The game will now close.")
        quit() # The game closes when the player no longer has chips, as the player must make bets in order to play
        
    # When round ends, user prompted to play another round or quit
    choice = play_again_menu()

    if choice == "Quit":
        msgbox("The player has quit. The game will now close.")
        quit()
    else:
        main_game_loop(Chips)

Chips = 50 # Player starts off with 50 chips and this variable tracks the changing number of the player's chips throughout the round
main_game_loop(Chips) # Game runs when the main game's loop is called
